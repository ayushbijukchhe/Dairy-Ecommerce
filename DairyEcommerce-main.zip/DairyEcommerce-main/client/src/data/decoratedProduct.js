export const decoratedProducts = [
   {
      decorationName: "juju_dhau_wedding_flower",
      img: "/assets/decoratedProduct/juju_dhau_wedding_flower.jpg",
   },
   {
      decorationName: "juju_dhau_wedding_love",
      img: "/assets/decoratedProduct/juju_dhau_wedding_love.jpg",
   },
   {
      decorationName: "juju_dhau_wedding_round",
      img: "/assets/decoratedProduct/juju_dhau_wedding_round.jpg",
   },
   {
      decorationName: "juju_dhau_wedding_simple",
      img: "/assets/decoratedProduct/juju_dhau_wedding_simple.jpg",
   },
]
