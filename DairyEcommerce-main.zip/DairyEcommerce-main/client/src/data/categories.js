export const categories = [
   {
      name: "curd",
   },
   {
      name: "cake",
   },
   {
      name: "cheese",
   },
]
