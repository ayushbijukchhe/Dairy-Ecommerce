export const occasions = [
   {
      name: "Birthday",
   },
   {
      name: "Bratabanda",
   },
   {
      name: "Wedding",
   },
   {
      name: "Picnic",
   },
   {
      name: "Festivals",
   },
   {
      name: "Others",
   },
]
