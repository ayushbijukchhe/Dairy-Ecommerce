import nodemailer from "nodemailer"

export const sendMail = () => {}
